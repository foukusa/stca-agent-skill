# 支持的数据与性质

[English](README.md) · [主说明](../../README.zh-CN.md) · 版本 **0.1.0**

## 目录

- [从内置任务开始](#从内置任务开始)
- [选择规则与方法](#选择规则与方法)
- [使用现成规则](#使用现成规则)
- [数据来源与字段](#数据来源与字段)
- [学习保存并继续使用](#学习保存并继续使用)

主计算演示见[ADEPT单体能隙](../adept_gap/README.zh-CN.md)，包含同一文件的筛选、规则学习和生成。

## 从内置任务开始

启用 STCA 后可发送 **“开始使用 STCA”**，或直接说明目标：

1. **上传数据总结规则**：提供结构和数值性质，并说明高低方向；百分比可自定，未指定时使用 10%、20%、30%。
2. **用已有规则筛选**：上传候选表，选择内置规则或刚保存的规则。
3. **用已有规则生成**：查看目录并选定规则，再选择预览确认 prompt 或直接生成。

完整处理 prompt 已内置。AI 助手读取表头，展示可选来源，只补问必要信息。无需输入规则 ID 或技术命令。

## 选择规则与方法

[规则与生成 prompt 目录](../../docs/RULE_LIBRARY.zh-CN.md)包含 **13 项公开数据性质任务**：GAS 实测数据 2 项、RadonPy 计算数据 5 项、ADEPT 计算数据 5 项，以及 OpenPoly 水接触角。source 训练的冻结规则针对**高值方向 Top 10%、20%、30%**。

每个来源、性质和百分比均分别列出 **STCA 与 WRAcc 的结果及规则可用状态**。可以接受推荐，也可以自行选择可用规则；目录提供评分与推荐理由，选定规则内部的条件须同时满足。

各方法、各档位的可用状态以当前计算为准。没有有效规则时保留具体原因，不能用空条件表示全部结构通过。

各任务、各百分比结果见[当前规则与筛选评分](current_rule_metrics.csv)。新规则先按 **ECFP4 Morgan 距离划分**，再仅用 source 学习；每条外部 holdout 到 source 的最近邻 Tanimoto 距离 **≥ 0.5**。方法推荐由 source 内另一层 Morgan 验证确定，随后才评价外部 holdout。推荐沿用作者 [STCA 论文](https://doi.org/10.1038/s41524-026-02345-x)的平均筛选评分。可以说“使用推荐方法”，也可明确选择 STCA 或 WRAcc。详见[评价说明](../../docs/MORGAN_EVALUATION.zh-CN.md)。

从自己的数据学习时，WRAcc 默认在训练数据内部选择条件数；也可要求“最多 10 个条件”或“不限制条件数”。

需要其他方向或 **15%、25%** 等百分比时，可上传合适的带标签数据学习新规则。例如：“从这份计算数据总结高折射率 Top 15%、25% 规则。”

## 使用现成规则

上传候选表后，可以直接发送：

| 目标 | 一句话开始 |
|---|---|
| 高 CO₂ 渗透率 | “用 GAS 实测数据的高 CO₂ 渗透率 Top 10% 规则，使用推荐方法筛选这份表。” |
| 高 O₂ 渗透率 | “用 GAS 实测数据的高 O₂ 渗透率 Top 10% 规则，使用推荐方法筛选候选。” |
| 高比热容 | “使用 RadonPy 的高比热容 Top 10% 规则，按推荐方法筛选我的候选。” |
| 高介电常数 | “使用 ADEPT 的高介电常数 Top 20% 规则，按推荐方法筛选这份表。” |

规则目录会给出所选任务的当前推荐。也可以先查看两种方法的分数，再自行选择。高介电常数与低介电常数是不同目标；需要低值方向时，可使用自己的数据重新学习。

需要生成时，可先说“查看可用的生成规则”，或直接指定来源、性质、百分比和方法，例如：“选择 ADEPT 高介电常数 Top 20% 的推荐规则，直接生成 20 个候选并核验。”想先检查时，发送“生成前先给我看完整 prompt”，可以修改后再回复“确认，开始生成”。两种方式都由当前 LLM 实际生成候选。

## 数据来源与字段

这 13 项公开数据任务用于 STCA 规则归纳，以及向结构距离较远聚合物迁移的评价。数据来源及标签类型如下：

| 来源 | 数据与原始研究 | 使用的标签 |
|---|---|---|
| GAS | [Dataset A](https://github.com/jsunn-y/PolymerGasMembraneML/blob/30981d71e1e3f12a057e009cd79f119bc659c7f5/datasets/datasetA_imputed_all.csv) · [原始论文](https://doi.org/10.1126/sciadv.abn9545) | CO₂、O₂ 实测渗透率 |
| RadonPy | [PI1070](https://github.com/RadonPy/RadonPy/blob/db5732b7fdd0b656d9c06d89151066d1edfbe911/data/PI1070.csv) · [原始论文](https://doi.org/10.1038/s41524-022-00906-4) | 分子动力学计算性质 |
| ADEPT | [PolyGraphMT 数据](https://github.com/sobinalosious/PolyGraphMT/tree/1c51a8578b6d23bd45bae7f7e175516dc22a3ed9/data/raw) · [原始论文](https://doi.org/10.1039/D6DD00206D) | MD 计算性质及 DFT 孤立单体能隙 |
| OpenPoly | [原始性质表](https://github.com/WangGroupFDU/Openpoly_benchmark/blob/ccaa66900747bfc576ef935e3d5f220b6c9b1f85/data/final_polymer_properties_fromliterature.csv) · [原始论文](https://doi.org/10.1007/s10118-025-3402-y) | 文献报道的水接触角 |

GAS 规则使用原始 `CO2`、`O2` 列的实测值。缺失值不参与归纳，Bayesian、Etree 插补列不作为实测标签替代。

上传这些来源文件时，可保留原始列名：

| 性质 | 数据文件 | 结构列 | 性质列 | 单位 |
|---|---|---|---|---|
| CO₂ 渗透率 | Dataset A：`datasetA_imputed_all.csv` | `Smiles` | `CO2` | Barrer |
| O₂ 渗透率 | Dataset A：`datasetA_imputed_all.csv` | `Smiles` | `O2` | Barrer |
| 热导率 | RadonPy：`PI1070.csv` | `smiles` | `thermal_conductivity` | W/(m K) |
| 折射率 | RadonPy：`PI1070.csv` | `smiles` | `refractive_index` | 无量纲 |
| 密度 | RadonPy：`PI1070.csv` | `smiles` | `density` | g/cm³ |
| 比热容 | RadonPy：`PI1070.csv` | `smiles` | `Cp` | J/(kg K) |
| 介电常数 | RadonPy：`PI1070.csv` | `smiles` | `dielectric_const_dc` | 无量纲 |
| 热导率 | ADEPT：`TC_MD.csv` | `SMILES` | `TC` | W/(m K) |
| 密度 | ADEPT：`RHO_MD.csv` | `SMILES` | `RHO` | g/cm³ |
| 孤立单体 HOMO–LUMO 能隙 | ADEPT：`BANDGAP_DFT.csv` | `SMILES` | `BANDGAP` | eV |
| 介电常数 | ADEPT：`DC_MD.csv` | `SMILES` | `DC` | 无量纲 |
| 折射率 | ADEPT：`RI_MD.csv` | `SMILES` | `RI` | 无量纲 |
| 水接触角 | OpenPoly：[`OpenPoly.csv`](../water_contact_angle/OpenPoly.csv) | `PSMILES` | `Water Contact Angle (deg)` | 度 |

OpenPoly水接触角作为[支持性质](../../docs/RULE_LIBRARY.zh-CN.md#openpoly水接触角)保留Top10%、20%、30%的两方法规则及实际评价结果，用于展示适用范围。原始表和字段见[来源说明](../water_contact_angle/README.zh-CN.md)；0°是有效数值。

ADEPT 能隙指氢封端孤立单体的 DFT HOMO–LUMO 能隙。[来源与字段索引](dataset_registry.csv)列出数据链接、原始列名、单位与许可信息；使用数据时请引用原始来源。

自己的学习数据需要结构和数值性质；单位、实验或计算来源及已有划分等信息，可在需要时补充。标识列可省略或任意命名。

总结规则必须明确绑定**结构列、数值性质列及单位**，可以在请求中直接指定。对于ADEPT等已知数据，配置已给出列映射；自己的文件则先读取表头，并在学习前显示将使用的列名、目标含义和单位。如果同时有实测与计算密度、不同温度，或均值与最小／最大值等多个可能目标，会先请你选择。你明确指定的列名优先；不能只看数值范围判断哪列是密度。使用已有规则筛选候选只需结构列，不要求候选已有性质标签。

上传原始重复单元 SMILES 时，**保留其中的 `*` 连接点**。STCA 保存这份原文，另建计算副本：把支持的末端单键连接点用氢封端（**H-cap**），再计算指纹。返回结果时使用保存的原始 SMILES，`*` 的位置与输入一致。这里不是字符串替换，也不从封端分子反推连接点。已经封端的输入保持原样，不凭空补星号。即使 H-cap 计算副本相同，原始连接位置不同的重复单元也保留为各自的记录。

| 上传的原始结构 | H-cap 计算副本 | 返回的结构 |
|---|---|---|
| `*CCO*` | `CCO` | `*CCO*` |

## 学习保存并继续使用

先按结构划分，再仅使用 source 标签，对每个百分比独立选择数据准备和扫描设置。同一输入、版本和设置下，单独请求某个百分比，或同时请求其他百分比，这一档的结果相同。

总结完成后，STCA 返回规则、物理阈值，以及**每种方法在每个请求档位的独立筛选结果**。默认筛选原始上传表；如果另传独立候选表，会将该候选表的筛选结果另列。

各筛选表保留原始带星号 SMILES 和标识，包含入选判断、每条未满足的规则条件及无法计算记录。某种方法或档位没有有效规则时，仍返回状态与原因，不用空条件表示全部通过。

模型、规则及完整中英文生成 prompt 自动保存为可复用文件；AI 助手显示实际保存位置和规则包。接着说“用刚才保存的规则筛选这份表”或“按刚才的规则生成”即可继续。换会话或平台时，上传保存的规则包继续使用。

选定生成规则后，可选**先预览，确认后生成**或**直接生成**。两种方式都返回全部提案及核验结果，包括未满足的规则条件，交付后可继续对话，无需另外配置 LLM API。需要转到其他 LLM 时，可明确请求 **“只给完整生成 prompt”**；之后上传其候选表，发送 **“按同一规则核验这些候选”**。结构规则核验与实际物性是否达标分别报告。安装步骤见[安装说明](../../docs/INSTALL.zh-CN.md)，完整对话见[自然语言使用案例](../../docs/USAGE.zh-CN.md)。
