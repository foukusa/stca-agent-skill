---
name: "stca"
display_name: "STCA 规则与设计"
display_name_en: "STCA Rules and Design"
description: "Use STCA to learn and save readable polymer rules, screen with bundled or saved rules, or invoke the current LLM to generate and verify structures. Choose preview/edit/confirm or direct generation. Preserve exact rules and original starred SMILES. Triggers: STCA、聚合物筛选、规则归纳、生成prompt。"
description_zh: "从上传数据学习并保存STCA/WRAcc可读规则，使用现成或自己的规则筛选候选，或按完整prompt生成并核验新结构。"
description_en: "Learn and save readable STCA/WRAcc rules from uploaded data, screen candidates with existing rules, or generate and verify structures using complete prompts."
version: "0.1.0"
author: "Weihao Wang"
examples_zh: ["开始使用 STCA。", "使用 STCA，帮我从这份数据总结规则。", "使用 STCA，按选定规则生成20个候选并核验。"]
examples_en: ["Start STCA.", "Use STCA to learn rules from this data.", "Use STCA to generate and verify 20 candidates with my selected rules."]
---

# STCA skill

Use natural language to learn and save rules from uploaded data, screen with
existing rules, or ask the current LLM to generate and verify candidates.
Keep version **0.1.0**, original starred SMILES, and all frozen rule conditions.

## Prepare once, then continue the user's task

1. Resolve `SKILL_DIR` as the directory containing this installed `SKILL.md`.
   With an available Python 3.10+ interpreter (`python3` or `python`), execute:

   ```bash
   python3 "$SKILL_DIR/scripts/workbuddy_runtime.py" prepare
   ```

2. Read the **entire** file at `skill_instructions` in the returned JSON.
   Follow that file immediately and continue the user's request in this turn.
   Preparation alone is not task completion. Do not ask the user to execute
   commands, supply paths, or repackage files.
3. Use the returned `runtime_skill_dir` as **SKILL_DIR for every subsequent
   script, asset and reference**. All complete rules, bilingual prompts,
   examples and workflows are available there. Keep the current working
   directory for the user's relative input/output paths.
4. Never read `assets/runtime_payload.json` into the conversation. The bundled
   preparation script verifies and restores it automatically, without network
   access, scientific dependencies, or writes to the installed skill directory.
   Ordinary dependency preparation remains managed by the restored
   `scripts/agent_runtime.py` when a calculation is requested.

If no execution tool or Python is available, explain the actual missing
capability; do not claim that preparation or screening has completed.

## Start and return

用户说“开始使用 STCA”时，按完整执行说明展示：

1. 上传自己的文件总结规则，并给出对应筛选结果、保存规则。
2. 根据已有规则直接筛选。
3. 根据已有规则直接生成，并逐条核验。

任务已明确时直接继续。生成先选择规则，再按用户选择预览、调整并确认
prompt 后调用当前 LLM，或直接生成并核验。完成后返回主菜单，保留已保存
规则。其他默认百分比、STCA/WRAcc 双结果和推荐标准均遵循准备后的完整说明。
