---
name: "stca"
display_name: "STCA 聚合物规则与设计"
display_name_en: "STCA Polymer Rules and Design"
description: "Use STCA for polymer structure-property rules, screening and repeat-unit design. Learn and save readable STCA/WRAcc rules from uploaded polymer data, apply existing rules, or generate and verify polymer repeat units with the current LLM. Preserve original SMILES and exact rule conditions. Triggers: STCA、聚合物筛选、规则归纳、多性能筛选、聚合物设计、生成prompt。"
description_zh: "从聚合物结构与性质数据中总结并保存可读规则，返回筛选结果；也可选择现成规则筛选候选，或调用当前 AI 按规则生成新的聚合物重复单元并逐条核验。支持自定义目标百分比、多性质联合筛选，以及生成前预览和调整 prompt。"
description_en: "Learn and save readable rules from polymer structures and property data, with screening results. Choose existing rules to screen candidates or guide the current AI in generating and verifying polymer repeat units. Supports custom target percentages, joint property screening and editable generation prompts."
version: "0.1.0"
author: "Weihao Wang"
examples_zh:
  - "使用 STCA，从这份聚合物数据总结规则并返回筛选结果。"
  - "使用 STCA，选择已有规则筛选我的聚合物候选表。"
  - "使用 STCA，先选规则，再直接生成 20 个聚合物重复单元并核验。"
examples_en:
  - "Use STCA to learn rules from this polymer dataset and return screening results."
  - "Use STCA to choose existing rules and screen my polymer candidates."
  - "Use STCA to choose a rule, then directly generate and verify 20 polymer repeat units."
---

# STCA skill

Use natural language to learn and save rules from uploaded polymer data, screen
with existing rules, or ask the current LLM to generate and verify polymer repeat units.
Keep version **0.1.0**, original polymer SMILES and repeat-unit attachment points, and all frozen rule conditions.

## Prepare once, then continue the user's task

1. Resolve `SKILL_DIR` as the directory containing this installed `SKILL.md`.
   On macOS or Linux, use the bundled launcher to find Python automatically:

   ```bash
   sh "$SKILL_DIR/scripts/launch_runtime.sh" --script "$SKILL_DIR/scripts/workbuddy_runtime.py" prepare
   ```

   On Windows, use `scripts/launch_runtime.ps1` with the same `--script`
   target and `prepare` argument. Both launchers are self-contained; the user
   does not enter a Python path. An explicit `--bootstrap-python` path is an optional
   override, and must not silently fall back to another interpreter.

2. Read the **entire** file at `skill_instructions` in the returned JSON.
   Follow that file immediately and continue the user's request in this turn.
   Preparation alone is not task completion. Do not ask the user to execute
   commands, supply paths, or repackage files.
3. Use the returned `runtime_skill_dir` as **SKILL_DIR for every subsequent
   script, asset and reference**. All complete rules, bilingual prompts,
   examples and workflows are available there. Keep the current working
   directory for the user's relative input/output paths.
4. Never read `assets/runtime_payload.json` into the conversation. The bundled
   preparation script verifies and restores it automatically, without network
   access, scientific dependencies, or writes to the installed skill directory.
   Dependency discovery and preparation are managed by
   `scripts/agent_runtime.py` when a calculation is requested. This actual
   entry point is also included in this upload package: it restores the
   verified resources and forwards every argument to the complete runtime.

If no execution tool or Python is available, explain the actual missing
capability; do not claim that preparation or screening has completed.

## Start and return

用户说“开始使用 STCA”时，按完整执行说明展示：

1. 上传自己的文件总结规则，并给出对应筛选结果、保存规则。
2. 根据已有规则直接筛选。
3. 根据已有规则直接生成，并逐条核验。

任务已明确时直接继续。生成先选择规则，再按用户选择预览、调整并确认
prompt 后调用当前 LLM，或直接生成并核验。完成后返回主菜单，保留已保存
规则。其他默认百分比、STCA/WRAcc 双结果和推荐标准均遵循准备后的完整说明。
