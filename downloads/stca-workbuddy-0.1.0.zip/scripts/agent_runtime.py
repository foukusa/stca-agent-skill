#!/usr/bin/env python3
"""Run the complete STCA agent after verified WorkBuddy resource restoration.

This public entry preserves every command-line argument and the user's working
directory. The full calculation implementation is bundled in the verified
runtime payload; no network or scientific dependency is needed for restoration.
"""
import sys
from workbuddy_runtime import run_agent_runtime

if __name__ == "__main__":
    raise SystemExit(run_agent_runtime(sys.argv[1:]))
